﻿namespace Astronomical_Processing_Application
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ListNeutrinoData = new System.Windows.Forms.ListBox();
            this.TextSearch = new System.Windows.Forms.TextBox();
            this.ButtonBinarySearch = new System.Windows.Forms.Button();
            this.ButtonSequentialSearch = new System.Windows.Forms.Button();
            this.TextResult = new System.Windows.Forms.TextBox();
            this.ButtonBubbleSort = new System.Windows.Forms.Button();
            this.ButtonEdit = new System.Windows.Forms.Button();
            this.ButtonMidExtreme = new System.Windows.Forms.Button();
            this.ButtonMode = new System.Windows.Forms.Button();
            this.ButtonAverage = new System.Windows.Forms.Button();
            this.ButtonRange = new System.Windows.Forms.Button();
            this.TextMidExtreme = new System.Windows.Forms.TextBox();
            this.TextMode = new System.Windows.Forms.TextBox();
            this.TextAverage = new System.Windows.Forms.TextBox();
            this.TextRange = new System.Windows.Forms.TextBox();
            this.TextBoxEditInput = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // ListNeutrinoData
            // 
            this.ListNeutrinoData.FormattingEnabled = true;
            this.ListNeutrinoData.Location = new System.Drawing.Point(12, 12);
            this.ListNeutrinoData.Name = "ListNeutrinoData";
            this.ListNeutrinoData.Size = new System.Drawing.Size(120, 199);
            this.ListNeutrinoData.TabIndex = 0;
            // 
            // TextSearch
            // 
            this.TextSearch.Location = new System.Drawing.Point(142, 12);
            this.TextSearch.Name = "TextSearch";
            this.TextSearch.Size = new System.Drawing.Size(100, 20);
            this.TextSearch.TabIndex = 1;
            // 
            // ButtonBinarySearch
            // 
            this.ButtonBinarySearch.Location = new System.Drawing.Point(248, 12);
            this.ButtonBinarySearch.Name = "ButtonBinarySearch";
            this.ButtonBinarySearch.Size = new System.Drawing.Size(105, 23);
            this.ButtonBinarySearch.TabIndex = 2;
            this.ButtonBinarySearch.Text = "Binary Search";
            this.ButtonBinarySearch.UseVisualStyleBackColor = true;
            this.ButtonBinarySearch.Click += new System.EventHandler(this.ButtonBinarySearch_Click);
            // 
            // ButtonSequentialSearch
            // 
            this.ButtonSequentialSearch.Location = new System.Drawing.Point(248, 41);
            this.ButtonSequentialSearch.Name = "ButtonSequentialSearch";
            this.ButtonSequentialSearch.Size = new System.Drawing.Size(105, 23);
            this.ButtonSequentialSearch.TabIndex = 3;
            this.ButtonSequentialSearch.Text = "Sequential Search";
            this.ButtonSequentialSearch.UseVisualStyleBackColor = true;
            this.ButtonSequentialSearch.Click += new System.EventHandler(this.ButtonSequentialSearch_Click);
            // 
            // TextResult
            // 
            this.TextResult.Location = new System.Drawing.Point(359, 14);
            this.TextResult.Name = "TextResult";
            this.TextResult.ReadOnly = true;
            this.TextResult.Size = new System.Drawing.Size(150, 20);
            this.TextResult.TabIndex = 4;
            // 
            // ButtonBubbleSort
            // 
            this.ButtonBubbleSort.Location = new System.Drawing.Point(248, 70);
            this.ButtonBubbleSort.Name = "ButtonBubbleSort";
            this.ButtonBubbleSort.Size = new System.Drawing.Size(105, 23);
            this.ButtonBubbleSort.TabIndex = 5;
            this.ButtonBubbleSort.Text = "Sort";
            this.ButtonBubbleSort.UseVisualStyleBackColor = true;
            this.ButtonBubbleSort.Click += new System.EventHandler(this.ButtonBubbleSort_Click);
            // 
            // ButtonEdit
            // 
            this.ButtonEdit.Location = new System.Drawing.Point(248, 99);
            this.ButtonEdit.Name = "ButtonEdit";
            this.ButtonEdit.Size = new System.Drawing.Size(105, 23);
            this.ButtonEdit.TabIndex = 6;
            this.ButtonEdit.Text = "Edit";
            this.ButtonEdit.UseVisualStyleBackColor = true;
            this.ButtonEdit.Click += new System.EventHandler(this.ButtonEdit_Click);
            // 
            // ButtonMidExtreme
            // 
            this.ButtonMidExtreme.Location = new System.Drawing.Point(248, 128);
            this.ButtonMidExtreme.Name = "ButtonMidExtreme";
            this.ButtonMidExtreme.Size = new System.Drawing.Size(105, 23);
            this.ButtonMidExtreme.TabIndex = 7;
            this.ButtonMidExtreme.Text = "Mid-Extreme";
            this.ButtonMidExtreme.UseVisualStyleBackColor = true;
            this.ButtonMidExtreme.Click += new System.EventHandler(this.ButtonMidExtreme_Click);
            // 
            // ButtonMode
            // 
            this.ButtonMode.Location = new System.Drawing.Point(248, 157);
            this.ButtonMode.Name = "ButtonMode";
            this.ButtonMode.Size = new System.Drawing.Size(105, 23);
            this.ButtonMode.TabIndex = 8;
            this.ButtonMode.Text = "Mode";
            this.ButtonMode.UseVisualStyleBackColor = true;
            this.ButtonMode.Click += new System.EventHandler(this.ButtonMode_Click);
            // 
            // ButtonAverage
            // 
            this.ButtonAverage.Location = new System.Drawing.Point(248, 186);
            this.ButtonAverage.Name = "ButtonAverage";
            this.ButtonAverage.Size = new System.Drawing.Size(105, 23);
            this.ButtonAverage.TabIndex = 9;
            this.ButtonAverage.Text = "Average";
            this.ButtonAverage.UseVisualStyleBackColor = true;
            this.ButtonAverage.Click += new System.EventHandler(this.ButtonAverage_Click);
            // 
            // ButtonRange
            // 
            this.ButtonRange.Location = new System.Drawing.Point(248, 215);
            this.ButtonRange.Name = "ButtonRange";
            this.ButtonRange.Size = new System.Drawing.Size(105, 23);
            this.ButtonRange.TabIndex = 10;
            this.ButtonRange.Text = "Range";
            this.ButtonRange.UseVisualStyleBackColor = true;
            this.ButtonRange.Click += new System.EventHandler(this.ButtonRange_Click);
            // 
            // TextMidExtreme
            // 
            this.TextMidExtreme.Location = new System.Drawing.Point(359, 130);
            this.TextMidExtreme.Name = "TextMidExtreme";
            this.TextMidExtreme.Size = new System.Drawing.Size(150, 20);
            this.TextMidExtreme.TabIndex = 11;
            // 
            // TextMode
            // 
            this.TextMode.Location = new System.Drawing.Point(359, 159);
            this.TextMode.Name = "TextMode";
            this.TextMode.Size = new System.Drawing.Size(150, 20);
            this.TextMode.TabIndex = 12;
            // 
            // TextAverage
            // 
            this.TextAverage.Location = new System.Drawing.Point(359, 188);
            this.TextAverage.Name = "TextAverage";
            this.TextAverage.Size = new System.Drawing.Size(150, 20);
            this.TextAverage.TabIndex = 13;
            // 
            // TextRange
            // 
            this.TextRange.Location = new System.Drawing.Point(359, 217);
            this.TextRange.Name = "TextRange";
            this.TextRange.Size = new System.Drawing.Size(150, 20);
            this.TextRange.TabIndex = 14;
            // 
            // TextBoxEditInput
            // 
            this.TextBoxEditInput.Location = new System.Drawing.Point(359, 101);
            this.TextBoxEditInput.Name = "TextBoxEditInput";
            this.TextBoxEditInput.ReadOnly = true;
            this.TextBoxEditInput.Size = new System.Drawing.Size(150, 20);
            this.TextBoxEditInput.TabIndex = 19;
            this.TextBoxEditInput.Text = "Enter index,value";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.TextBoxEditInput);
            this.Controls.Add(this.TextRange);
            this.Controls.Add(this.TextAverage);
            this.Controls.Add(this.TextMode);
            this.Controls.Add(this.TextMidExtreme);
            this.Controls.Add(this.ButtonRange);
            this.Controls.Add(this.ButtonAverage);
            this.Controls.Add(this.ButtonMode);
            this.Controls.Add(this.ButtonMidExtreme);
            this.Controls.Add(this.ButtonEdit);
            this.Controls.Add(this.ButtonBubbleSort);
            this.Controls.Add(this.TextResult);
            this.Controls.Add(this.ButtonSequentialSearch);
            this.Controls.Add(this.ButtonBinarySearch);
            this.Controls.Add(this.TextSearch);
            this.Controls.Add(this.ListNeutrinoData);
            this.Name = "Form1";
            this.Text = "Astronomical Processing Application";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox ListNeutrinoData;
        private System.Windows.Forms.TextBox TextSearch;
        private System.Windows.Forms.Button ButtonBinarySearch;
        private System.Windows.Forms.Button ButtonSequentialSearch;
        private System.Windows.Forms.TextBox TextResult;
        private System.Windows.Forms.Button ButtonBubbleSort;
        private System.Windows.Forms.Button ButtonEdit;
        private System.Windows.Forms.Button ButtonMidExtreme;
        private System.Windows.Forms.Button ButtonMode;
        private System.Windows.Forms.Button ButtonAverage;
        private System.Windows.Forms.Button ButtonRange;
        private System.Windows.Forms.TextBox TextMidExtreme;
        private System.Windows.Forms.TextBox TextMode;
        private System.Windows.Forms.TextBox TextAverage;
        private System.Windows.Forms.TextBox TextRange;
        private System.Windows.Forms.TextBox TextBoxEditInput;
    }
}

