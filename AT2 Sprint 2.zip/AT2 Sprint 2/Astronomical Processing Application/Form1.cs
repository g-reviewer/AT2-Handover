﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Astronomical_Processing_Application
{
    public partial class Form1: Form
    {
        int[] neutrinoData = new int[24];
        Random rand = new Random();

        ToolTip toolTip1 = new ToolTip();
        public Form1()
        {
            InitializeComponent();
            GenerateNeutrinoData();
            SetToolTips();
        }
        private void GenerateNeutrinoData()
        {
            for (int i = 0; i < neutrinoData.Length; i++)
            {
                neutrinoData[i] = rand.Next(0, 101);
                ListNeutrinoData.Items.Add(neutrinoData[i]);
            }
        }

        private void SetToolTips()
        {
            toolTip1.SetToolTip(ListNeutrinoData, "Displays 24 random neutrino interaction values");
            toolTip1.SetToolTip(TextSearch, "Enter a number to search");
            toolTip1.SetToolTip(ButtonBinarySearch, "Click to perform a Binary Search");
            toolTip1.SetToolTip(ButtonBubbleSort, "Click to sort the data using Bubble Sort");
            toolTip1.SetToolTip(ButtonSequentialSearch, "Click to perform a Sequential Search");
            toolTip1.SetToolTip(ButtonMidExtreme, "Calculate and display Mid-Extreme value");
            toolTip1.SetToolTip(ButtonMode, "Calculate and display Mode value");
            toolTip1.SetToolTip(ButtonAverage, "Calculate and display Average value");
            toolTip1.SetToolTip(ButtonRange, "Calculate and display Range value");
            toolTip1.SetToolTip(ButtonEdit, "Click to edit a neutrino value at the specified index");
        }
        private double CalculateMidExtreme()
        {
            int min = neutrinoData.Min();
            int max = neutrinoData.Max();
            return (min + max) / 2;
        }
        private (int mode, int count) CalculateMode()
        {
            var modeGroup = neutrinoData.GroupBy(x => x)
                .OrderByDescending(g => g.Count())
                .ThenBy(g => g.Key)
                .First();
            return (modeGroup.Key, modeGroup.Count());
        }
        private double CalculateAverage()
        {
            return neutrinoData.Average();
        }
        private int CalculateRange()
        {
            return neutrinoData.Max() - neutrinoData.Min();
        }

        private void ButtonMidExtreme_Click(object sender, EventArgs e)
        {
            TextMidExtreme.Text = CalculateMidExtreme().ToString("F2");
        }

        private void ButtonMode_Click(object sender, EventArgs e)
        {
            var modeData = CalculateMode();
            TextMode.Text = $"Mode: {modeData.mode}, Occurrences: {modeData.count}";
        }

        private void ButtonAverage_Click(object sender, EventArgs e)
        {
            TextAverage.Text = CalculateAverage().ToString("F2");
        }

        private void ButtonRange_Click(object sender, EventArgs e)
        {
            TextRange.Text = CalculateRange().ToString();
        }

        private void ButtonBubbleSort_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < neutrinoData.Length - 1; i++)
            {
                for (int j = 0; j < neutrinoData.Length - i - 1; j++)
                {
                    if (neutrinoData[j] > neutrinoData[j + 1])
                    {
                        int temp = neutrinoData[j];
                        neutrinoData[j] = neutrinoData[j + 1];
                        neutrinoData[j + 1] = temp;
                    }
                }
            }

            ListNeutrinoData.Items.Clear();
            foreach (int data in neutrinoData)
            {
                ListNeutrinoData.Items.Add(data);
            }
        }

        private void ButtonSequentialSearch_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TextSearch.Text))
            {
                MessageBox.Show("Search box cannot be empty.");
                return;
            }

            if (!int.TryParse(TextSearch.Text, out int target))
            {
                MessageBox.Show("Please enter a valid integer.");
                return;
            }

            bool found = false;
            for (int i = 0; i < neutrinoData.Length; i++)
            {
                if (neutrinoData[i] == target)
                {
                    TextResult.Text = $"Found at idex {i}";
                    found = true;
                    break;
                }
            }

            if (!found)
            {
                TextResult.Text = "Not Found";
            }
        }

        private void ButtonBinarySearch_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TextSearch.Text))
            {
                MessageBox.Show("Search box cannot be empty.");
                return;
            }

            if (!int.TryParse(TextSearch.Text, out int target))
            {
                MessageBox.Show("Please enter a valid integer.");
                return;
            }

            int left = 0, right = neutrinoData.Length - 1;
            bool found = false;

            while (left <= right)
            {
                int mid = left + (right - left) / 2;
                if (neutrinoData[mid] == target)
                {
                    TextResult.Text = $"Found at index {mid}";
                    found = true;
                    break;
                }
                else if (neutrinoData[mid] < target)
                {
                    left = mid + 1;
                }
                else
                {
                    right = mid - 1;
                }
            }

            if (!found)
            {
                TextResult.Text = "Not Found";
            }
        }

        private void ButtonEdit_Click(object sender, EventArgs e)
        {
            if (ListNeutrinoData.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a value from the list to replace.");
                return;
            }

            if (string.IsNullOrWhiteSpace(TextSearch.Text))
            {
                MessageBox.Show("Search box cannot be empty.");
                return;
            }

            if (!int.TryParse(TextSearch.Text, out int newValue))
            {
                MessageBox.Show("Invalid input. Please enter a valid integer.");
                return;
            }

            int selectedIndex = ListNeutrinoData.SelectedIndex;
            neutrinoData[selectedIndex] = newValue;

            ListNeutrinoData.Items[selectedIndex] = newValue;

            MessageBox.Show($"Value at index {selectedIndex} replaced with {newValue}.");
        }
    }
}
